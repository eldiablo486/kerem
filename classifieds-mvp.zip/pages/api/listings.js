import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export default async function handler(req, res){
  if(req.method === 'GET'){
    const listings = await prisma.listing.findMany({ orderBy: { createdAt: 'desc' }});
    res.status(200).json(listings);
  } else if(req.method === 'POST'){
    const { title, price, city, desc } = req.body;
    const created = await prisma.listing.create({
      data: { title, price, city, desc }
    });
    res.status(201).json(created);
  } else {
    res.status(405).end();
  }
}