import { useEffect, useState } from 'react';
import ListingCard from '../components/ListingCard';
import NewListingForm from '../components/NewListingForm';

export default function Home() {
  const [listings, setListings] = useState([]);
  useEffect(() => {
    fetch('/api/listings').then(r=>r.json()).then(setListings);
  }, []);

  async function addListing(item){
    const res = await fetch('/api/listings', {
      method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(item)
    });
    const n = await res.json();
    setListings(prev => [n, ...prev]);
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-4xl mx-auto mb-6">
        <h1 className="text-3xl font-bold">Mini İlan Sitesi — MVP</h1>
      </header>
      <main className="max-w-4xl mx-auto grid gap-6">
        <NewListingForm onAdd={addListing} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {listings.map(l => <ListingCard key={l.id} listing={l} />)}
        </div>
      </main>
    </div>
  );
}