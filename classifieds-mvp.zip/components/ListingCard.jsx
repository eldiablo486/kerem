export default function ListingCard({ listing }){
  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="h-40 bg-gray-200 rounded mb-3 flex items-center justify-center">Foto</div>
      <h3 className="font-semibold">{listing.title}</h3>
      <p className="text-sm text-gray-600">{listing.city} — {listing.price}</p>
      <p className="mt-2 text-sm">{listing.desc}</p>
    </div>
  );
}