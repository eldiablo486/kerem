import { useState } from 'react';
export default function NewListingForm({ onAdd }){
  const [title,setTitle] = useState(''); const [price,setPrice]=useState(''); const [city,setCity]=useState(''); const [desc,setDesc]=useState('');
  async function submit(e){ e.preventDefault(); if(!title) return; await onAdd({ title, price, city, desc }); setTitle(''); setPrice(''); setCity(''); setDesc(''); }
  return (
    <form onSubmit={submit} className="bg-white p-4 rounded shadow">
      <h2 className="font-semibold mb-2">Yeni İlan Ekle</h2>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Başlık" className="w-full mb-2 p-2 border rounded" />
      <input value={price} onChange={e=>setPrice(e.target.value)} placeholder="Fiyat" className="w-full mb-2 p-2 border rounded" />
      <input value={city} onChange={e=>setCity(e.target.value)} placeholder="Şehir" className="w-full mb-2 p-2 border rounded" />
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Açıklama" className="w-full mb-2 p-2 border rounded" />
      <button className="bg-blue-600 text-white px-4 py-2 rounded">Ekle</button>
    </form>
  );
}