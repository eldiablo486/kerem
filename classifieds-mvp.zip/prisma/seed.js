const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main(){
  await prisma.listing.createMany({
    data: [
      { title: 'İstanbul - Satılık 2+1 Daire', price: '1.250.000 TL', city: 'İstanbul', desc: 'Geniş, merkezi.' },
      { title: 'Ankara - Fiat Egea 2019', price: '420.000 TL', city: 'Ankara', desc: 'Bakımlı.' }
    ]
  })
}
main().then(()=>console.log('Seeded')).catch(e=>console.error(e)).finally(()=>prisma.$disconnect());
