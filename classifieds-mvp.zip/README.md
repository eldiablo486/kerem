# Classifieds MVP

Minimal Next.js + Tailwind prototype with Docker + Postgres (Prisma) example.

## Quick start (local)
1. Copy `.env.example` to `.env`
2. Run: `docker-compose up --build`
3. In another shell, run migrations:
   - `docker compose exec app npx prisma migrate deploy`
4. Visit http://localhost:3000

## Notes
- This is a development scaffold. Do not use in production without hardening.
